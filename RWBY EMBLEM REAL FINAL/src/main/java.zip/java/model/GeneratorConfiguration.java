package model;

/**
 * Created by Ciprian on 12/19/2015.
 */
public class GeneratorConfiguration {

    public boolean isKotlinController;
}
